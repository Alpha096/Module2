package com.cg.ssms.dao;

import java.util.List;

import com.cg.ssms.dto.Client;

public interface ITrainingDAO {

	public List<Client> getAllDetail();

}
