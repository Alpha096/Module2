package com.cg.springmvcthree.dao;
import java.util.List;

import com.cg.springmvcthree.dto.Mobile;

public interface IMobileDao {

	public List<Mobile> getAllDetail();

}
