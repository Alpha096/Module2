package com.cg.springmvcthree.service;
import java.util.List;

import com.cg.springmvcthree.dto.*;

public interface IMobileService {

	public List<Mobile> getAllDetail();
	

}
