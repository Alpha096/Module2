package com.cg.springmvcthree.service;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springmvcthree.dao.IMobileDao;
import com.cg.springmvcthree.dto.*;

@Service("mobileservice")
@Transactional
public class IMobileServiceImpl implements IMobileService{
	@Autowired
	IMobileDao mobiledao;
	
	
	public List<Mobile> getAllDetail(){
		return mobiledao.getAllDetail();
	}

}
